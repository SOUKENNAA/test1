

# Create your models here.
from django.db import models

class Competence(models.Model):
    nom = models.CharField(max_length=100)

    def _str_(self):
        return self.nom

class Projet(models.Model):
    nom = models.CharField(max_length=100)

    def _str_(self):
        return self.nom

class Certification(models.Model):
    nom = models.CharField(max_length=100)
    date_obtention = models.DateField()

    def _str_(self):
        return self.nom

class Travailleur(models.Model):
    nom_complet = models.CharField(max_length=255)
    date_naissance = models.DateField()
    adresse = models.CharField(max_length=255)
    numero_telephone = models.CharField(max_length=15)
    email = models.EmailField()
    poste = models.CharField(max_length=100)
    departement = models.CharField(max_length=100)
    date_embauche = models.DateField()
    type_contrat = models.CharField(max_length=50, choices=[('CDD', 'CDD'), ('CDI', 'CDI'), ('Freelance', 'Freelance')])
    salaire = models.DecimalField(max_digits=10, decimal_places=2)
    competences = models.ManyToManyField(Competence,on_delete=models.CASCADE)
    annees_experience = models.IntegerField()
    projets_precedents = models.ManyToManyField(Projet, related_name='projets_precedents', blank=True,on_delete=models.CASCADE)
    cv = models.FileField(upload_to='cvs/', blank=True, null=True)
    certifications = models.ManyToManyField(Certification, blank=True,on_delete=models.CASCADE)
    piece_identite = models.FileField(upload_to='pieces_identite/', blank=True, null=True)
    disponibilite = models.BooleanField(default=True)
    projets_actuels = models.ManyToManyField(Projet, related_name='projets_actuels', blank=True)
    horaires_travail = models.CharField(max_length=100)
    commentaires = models.TextField(blank=True, null=True)

    def _str_(self):
        return self.nom_complet